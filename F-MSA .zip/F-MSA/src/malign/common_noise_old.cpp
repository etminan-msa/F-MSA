#include "common_noise.h"

const size_t too_frequent = 1024;
Default_noise_filter default_noise_filter;

Common_noise::Common_noise()
{}


Common_noise::~Common_noise()
{
	for (size_t i = 0; i < _noise_entry.size(); i++)
	{
		if(_noise_entry[i] != NULL) delete [] _noise_entry[i];
	}
}


bool Common_noise::contains(uint64_t seed, uint64_t shape) const
{
	size_t start = 0, end = _limit[shape];
	noise *noise_entry_ = _noise_entry[shape];

	while (start <= end)
	{
		size_t mid = (start + end) / 2;
		if (noise_entry_[mid].seed == seed) return true;
		if (noise_entry_[mid].seed < seed) start = mid + 1;
		else                              end = mid - 1;
	}
	return false;
}

