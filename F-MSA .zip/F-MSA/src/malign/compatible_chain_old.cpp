#include "compatible_chain.h"
#include "progress.h"

//size_t Compatible_chain::sid;

Compatible_chain::Compatible_chain(Sorted_common_seed &sorted_common_seed, size_t sid)
	: matrix(1)
{
//	Compatible_chain::sid = sid;
//	vector <vector <CompatibleChain>> compatibleChains(1);
/*
	size_t data_size = 0;
	for (size_t k = 0; k < sorted_common_seed.index_.size(); k++)
	{
		Sorted_common_seed::Iterator it(sorted_common_seed.data_[sorted_common_seed.index_[k].index], sorted_common_seed.index_[k].pos, sorted_common_seed.min_pos_idx);
		for (; it.good(); it.next())
		{
			data_size++;
		}
	}
*/
	Progress prog(sorted_common_seed.total_common_seeds);

	for (uint32_t k = 0; k < sorted_common_seed.total_common_seeds/*data_.size()*/; k++)
	{
		prog.progress(k);
		bool chained = false;
		size_t i = matrix.size();
		Sorted_common_seed::Common_seed *common_seed_ptr = &sorted_common_seed.common_seed[k];
		do {
			i--;
			Chain_ **row = matrix[i].data();
			size_t size = matrix[i].size();
			
			Chain_ **ptr = row;
			for (size_t j = 0; j < size; j++, ptr++)
			{
				size_t offset;
				if (offset = (*ptr)->head.merge(common_seed_ptr))
				{
					(*ptr)->score += (1.0f + offset) / ::shapes[Sorted_common_seed::sid].length_;
					if ((*ptr)->score > best_chain_->score) best_chain_ = *ptr;
					chained = true;
					break;
				}
			}
			if (chained) break;

			vector <size_t> chainable_idx(size);
			size_t chainable_size = 0;
			ptr = row;
			for (size_t j = 0; j < size; j++, ptr++)
			{
				if (*common_seed_ptr >= *(*ptr)->head.common_seed_list.back())
				{
					chainable_idx[chainable_size] = j;
					chainable_size++;
				}
			}
			if (chainable_size > 0)
			{
				if (chain_idx == 0) chain_.push_back(new Chain_[chunk_size]);

				Chain_ &chain = chain_.back()[chain_idx];
				chain.head.set(common_seed_ptr);
				chain.size = 0;
				chain.tail.resize(chainable_size);
				for (uint16_t n = 0; n < chainable_size; n++)
				{
					Chain_ *chaild = row[chainable_idx[n]];
					chain.tail[n] = chaild;
					chain.size += chaild->size;
					if (chaild->score > chain.score)
					{
						chain.score = chaild->score;
						chain.best_score_idx = n;
					}
				}
				chain.score += 1;
				if (chain.score > best_chain_->score) best_chain_ = &chain;

				if (i == matrix.size() - 1)
				{
					matrix.push_back(vector <Chain_ *>());
				}
				matrix[i + 1].push_back(&chain);
				chain_idx++;
				chained = true;
				break;
			}
		} while (i > 0 && !chained);

		if (!chained)
		{
			if (chain_idx == 0) chain_.push_back(new Chain_[chunk_size]);
			Chain_ &chain = chain_.back()[chain_idx];
			chain.head.set(common_seed_ptr);
			matrix[0].push_back(&chain);
			chain_idx++;
		}
	}

	_best_longest_chain = new Chain;
	_extract_chain(best_longest_chain_(), *_best_longest_chain);
	if (best_chain_ != best_longest_chain_()) {
		_best_chain = new Chain;
		_extract_chain(best_chain_, *_best_chain);
	}
	else _best_chain = _best_longest_chain;

	prog.finish();

	chain_info.resize(matrix.size());
	for (size_t k = 0; k < matrix.size(); k++) {
		uint64_t size = 0;
		for (size_t j = 0; j < matrix[k].size(); j++) {
			size += matrix[k][j]->size;
		}
		chain_info[k] = size;

//		matrix[k].clear();
	}
	matrix.clear();

	for (size_t k = 0; k < chain_.size(); k++) {
//		for (size_t j = 0; j < chunk_size; j++) {
//			chain_[k][j].head.common_seed_list.clear();
//		}
		delete[] chain_[k];
	}
}


void Compatible_chain::Show()
{
	if (!config.verbose)
	{
		if (chain_info.size() == 0)
			message_stream << "-- NO COMPATIBLE CHAIN WAS FOUND" << endl;
		else
			message_stream << "-- Compatible chain length: " << chain_info.size() << endl;
		return;
	}
	const int chunk = 7;
	const int blocks = 5;
	int size = (int)chain_info.size();
	const int step = (int)std::ceil((double)(size - chunk) / (blocks - 1));
	message_stream << "\nChain" << endl;
	message_stream << "\nLength  Numbers" << endl;
	message_stream <<   "______  ________________" << endl;
	for (int k = 0, begin = 0, end = std::min(size, chunk); k < blocks;
		k++, begin = std::max(end, std::min(size - chunk, k * step)), end = std::min(size, begin + chunk))
	{
		for (size_t i = begin; i < end; i++) {
			message_stream << i + 1 << '\t' << chain_info[i] << endl;
		}

		if (size > blocks * chunk && k < blocks - 1 && end - begin <= chunk) message_stream << ".       ." << endl;
	}
}
