#pragma once
#ifndef COMMON_SEED_H
#define COMMON_SEED_H

#include <vector>
#include "../malign/sorted_list_ex.h"
#include "../malign/common_noise.h"

using std::vector;


//typedef vector<uint64_t> Position_list;
//typedef uint8_t *Common_seed_position_index;

struct Position_list_proxy
{
	Position_list_proxy() {}
	Position_list_proxy(entry * ptr, size_t size) : ptr_(ptr), size_(size) {}
	uint64_t operator [](size_t i) const
	{
		assert (i >= 0 && i < size_);
		return ptr_[i].value;
	}

	size_t size() const { return size_; }

private:
	size_t size_;
	entry * ptr_;
};

struct Common_seed_info
{
	Common_seed_info() {}
	Common_seed_info(uint64_t seed, Position_list_proxy *pos) :
		seed(seed), pos(pos)
	{}

	uint64_t seed;
	Position_list_proxy * pos;
};

struct Sorted_common_seed
{
	struct Common_seed_index
	{
		Common_seed_index() {}
		Common_seed_index(uint64_t pos, size_t index) :pos(pos), index(index) {}

		bool operator < (const Common_seed_index &right)
		{
			return pos < right.pos;
		}

		uint64_t pos;
		size_t index;
	};

	Sorted_common_seed(Sorted_seqs_seed &seqs, size_t sid, Seqs_histogram &hst, Common_noise &noise); //const Noise_filter *filter);

//	void Show();

	static void seed_worker(const Sorted_seqs_seed *seqs, size_t *range, Position_list_proxy *common_seed_pos_ptr, Common_seed_info *data_, size_t data_idx, Common_seed_index *index_ptr);

	vector <Common_seed_info> data_;
	vector<Position_list_proxy> common_seed_pos_;
	vector <Common_seed_index> index_;
//	size_t min_pos_idx = 0;
	size_t total_common_seeds = 0;
	static size_t seqs_size;
	static size_t pivot_seq;

	struct Iterator
	{
		Iterator(Common_seed_info &common_seed_info, uint64_t pivot_pos, uint8_t *index_ptr) :
			common_seed_info(common_seed_info),
//			_index(Sorted_common_seed::seqs_size),
//			pivot_index(pivot_index),
			index_ptr(index_ptr),
			pos_index(Sorted_common_seed::seqs_size),
			done(false)
		{
			for (uint8_t k = 0; k < common_seed_info.pos[Sorted_common_seed::pivot_seq].size(); k++)
			{
				if (common_seed_info.pos[Sorted_common_seed::pivot_seq][k] == pivot_pos)
				{
					pos_index[Sorted_common_seed::pivot_seq] = k;
					break;
				}
			}

/*			for (size_t j = 0; j < Sorted_common_seed::seqs_size; j++)
			{
				if (j == Sorted_common_seed::pivot_seq) continue;
				pos[j] = common_seed_info.pos[j][pos_index[j]];
			}
*/
		}

		bool good()
		{
			return !done;
		}

		void next()
		{
			for (size_t k = 0; k < Sorted_common_seed::seqs_size; k++)
			{
				if (k == Sorted_common_seed::pivot_seq)	continue;
				
				if (pos_index[k] >= common_seed_info.pos[k].size()-1)
				{
					pos_index[k] = 0;
					continue;
				}
				pos_index[k]++;
/*				for (size_t j = 0; j < _index.size(); j++)
				{
					if (j == pivot_index) continue;
					pos[j] = common_seed_info.pos[j][_index[j]];
				}
*/				return;
			}
			done = true;
		}

		const uint8_t *get()
		{
			memcpy(index_ptr, pos_index.data(), Sorted_common_seed::seqs_size);
			index_ptr += Sorted_common_seed::seqs_size;

			return index_ptr - Sorted_common_seed::seqs_size;
		}

		Common_seed_info &common_seed_info;
		uint8_t *index_ptr;
//		uint8_t pivot_pos_index;
//		size_t pivot_index;
		vector<uint8_t> pos_index;
		bool done;
	};
};

#endif // !COMMON_SEED_H

