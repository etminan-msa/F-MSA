#ifndef COMMON_NOISE_H_
#define COMMON_NOISE_H_

#include <vector>
#include <algorithm> 

#include "../Diamond/data/seed_set.h"
//#include "../Diamond/data/sorted_list.h"
//#include "../Diamond/util/ptr_vector.h"
//#include "../malign/seed_histogram_ex.h"
using std::vector;


extern const size_t too_frequent;
struct Noise_filter
{
	virtual bool valid(size_t freq) const
	{
		return freq <= too_frequent;
	}
};
extern Noise_filter no_noise_filter;

struct Default_noise_filter : Noise_filter
{
	virtual bool valid(size_t freq) const
	{
		return freq <= threshold;
	}

	void set_threshold(size_t thr)
	{
		threshold = std::min(thr, too_frequent);
	}
private:

	size_t threshold = 1;
};
extern Default_noise_filter default_noise_filter;


struct noise
{
	uint64_t seed;
	size_t freq;
	bool operator<(const noise &rhs) const
	{
		return seed < rhs.seed;
	}
};

struct Common_noise
{
	friend struct Sorted_common_seed;

	Common_noise();
	~Common_noise();

	template<typename _filter>
	Common_noise(const Sequence_set &seqs, const _filter *filter) :
		_noise_entry(shapes.count()),
		_limit(shapes.count())
	{
		size_t max_len = 0;
		for (size_t k = 1; k < seqs.get_length(); k++)
		{
			if (seqs.length(k) > max_len)
			{
				max_len = seqs.length(k);
			}
		}

		for (size_t i = 0; i < _noise_entry.size(); i++)
		{
			_noise_entry[i] = new noise[max_len];
		}
		vector<size_t> p{ 0, 1 };
		Ptr_vector<Callback> cb;
		cb.push_back(new Callback(_noise_entry, _limit));
		seqs.enum_seeds(cb, p, 0, shapes.count(), filter);

		for (size_t i = 0; i < _noise_entry.size(); i++)
		{
			std::sort(&_noise_entry[i][0], &_noise_entry[i][_limit[i]]);
		}

		vector<size_t> temp_limit(shapes.count());
		vector<noise *>temp_entry(shapes.count());
		for (size_t i = 0; i < temp_entry.size(); i++)
		{
			temp_entry[i] = new noise[max_len];
		}

		for (size_t k = 1; k < seqs.get_length(); k++)
		{
			p[0] = k; p[1] = k + 1;
			cb.clear();
			cb.push_back(new Callback(temp_entry, temp_limit));
			seqs.enum_seeds(cb, p, 0, shapes.count(), filter);

			for (size_t i = 0; i < temp_entry.size(); i++)
			{
				noise *temp_entry_i = temp_entry[i];
				std::sort(&temp_entry_i[0], &temp_entry_i[temp_limit[i]]);

				size_t temp_idx = 0, _idx = 0, limit_ = 0;
				noise *_noise_entry_i = _noise_entry[i];
				while (true)
				{
					while (temp_idx < temp_limit[i] && temp_entry_i[temp_idx].seed < _noise_entry_i[_idx].seed) temp_idx++;
					if (temp_idx == temp_limit[i]) break;
					while (_idx < _limit[i] && _noise_entry_i[_idx].seed < temp_entry_i[temp_idx].seed) _idx++;
					if (_idx == _limit[i]) break;
					if (_noise_entry_i[_idx].seed == temp_entry_i[temp_idx].seed)
					{
						_noise_entry_i[limit_].seed = _noise_entry_i[_idx].seed;
						_noise_entry_i[limit_++].freq = std::min(_noise_entry_i[_idx++].freq * temp_entry_i[temp_idx++].freq, too_frequent);
					}
				}
				temp_limit[i] = 0;
				_limit[i] = limit_;
			}
		}

		for (size_t i = 0; i < temp_entry.size(); i++)
		{
			delete[] temp_entry[i];
		}

		for (size_t i = 0; i < _noise_entry.size(); i++)
		{
			Sd statis;
			noise *_noise_entry_i = _noise_entry[i];
			for (size_t k = 0; k < _limit[i]; k++)
			{
				if (_noise_entry_i[k].freq < too_frequent) statis.add((double)_noise_entry_i[k].freq);
			}
			default_noise_filter.set_threshold((size_t)ceil(sqrt(statis.mean())));

			size_t limit_ = 0;
			for (size_t k = 0; k < _limit[i]; k++)
			{
				if (default_noise_filter.valid(_noise_entry_i[k].freq))
				{
					_noise_entry_i[limit_++] = _noise_entry_i[k];
				}
			}
			_limit[i] = limit_;
		}
	}

	bool contains(uint64_t key, uint64_t shape) const;

private:
	struct Callback
	{
		Callback(vector<noise *> _entry, vector<size_t> &_limit) :
			_entry(_entry),
			_limit(_limit) 
		{}

		bool operator()(uint64_t seed, uint64_t pos, size_t shape)
		{
			size_t i = 0;
			size_t &limit_ = _limit[shape];
			noise *entry_ = _entry[shape];
			for (; i < limit_; i++)
			{
				if (entry_[i].seed == seed)
				{
					entry_[i].freq++;
					break;
				}
			}
			if (i == limit_)
			{
				entry_[i].seed = seed;
				entry_[i].freq = 1;
				limit_++;
			}
			return true;
		}
		void finish() const
		{
		}
	private:
		vector<size_t> &_limit;
		vector<noise *> _entry;
	};

	vector<size_t> _limit;
	vector<noise *>_noise_entry;
};

#endif /* SORTED_LIST_EX_H_ */
